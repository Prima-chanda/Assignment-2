<html>

<head>
<title>Unit Converter - Home</title>
</head>

<body>
<h1 align=center><font color=red><b>Unit Converter<br>Select a field</b></font></h1>
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>

<h4><font face="Times Roman" size=5><pre>                     Welcome To Converter ....
                     Here is a converter that presents the conversion of units on six basic fields.
                     We hope it would help you in finding the exact answers.
                     Well go ahead and give it a try
</font></pre></h4>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="code/length.php"><acronym title="LENGTH"><img border="0" src="image/length.JPG" width="145" height="137"></acronym></a>
<a href="code/temp.php"><acronym title="TEMPERATURE"><img border="0" src="image/temp.JPG" width="146" height="134"></acronym></a>

<br><br><br><br><h1 align="right"><font size="3" color="#FF0000">Developed by Sharon Das<br></font></h1>
</body>

</html>
